import { Component } from '@angular/core';
import { IconType, ButtonType } from './common/modal/model/modal-data';
import { MessageService } from './common/service/modal/message.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { MessageBox } from './common/service/modal/message-box';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  html_title = 'ng9-material-modal';
  subscriber: Subscription;

  title: string;
  iconType: IconType;
  message: string;
  buttonType: any;
  allow_outside_click: any;
  width: string;


  
  constructor(
    private messageService: MessageService,
    private dialog: MatDialog) {}

  async openInfoModal() {
    console.log('openInfoModal()...');

    this.title = 'タイトル表示部';
    this.iconType = IconType.Info;
    this.message = 'このメッセージが見えますか？';
    this.buttonType = ButtonType.Ok;
    this.width = '50%';

    await MessageBox.show(this.dialog, this.message, this.title,
          this.buttonType, this.iconType, this.width)
        .subscribe( result => {
          const dialogResult = (result === undefined) ? 'none' : result.result;
          MessageBox.show(this.dialog, `User response : ${dialogResult}`);
    });
  }

   openWarningModal() {
    console.log('openWarningModal()...');

    this.title = 'タイトル表示部';
    this.iconType = IconType.Warning;
    this.message = 'このメッセージが見えますか？';
    this.buttonType = ButtonType.OkCancel;
    this.width = '500px';

    MessageBox.show(this.dialog, this.message, this.title,
          this.buttonType, this.iconType, this.width)
        .subscribe( result => {
          const dialogResult = (result === undefined) ? 'none' : result.result;
          MessageBox.show(this.dialog, `User response : ${dialogResult}`);
    });

  }

  openErrorModal() {
    console.log('openErrorModal()...');

    this.title = 'タイトル表示部';
    this.iconType = IconType.Error;
    this.message = 'このメッセージが見えますか？';
    this.buttonType = ButtonType.YesNo;
    this.width = '300px';

    MessageBox.show(this.dialog, this.message, this.title,
          this.buttonType, this.iconType, this.width)
        .subscribe( result => {
          const dialogResult = (result === undefined) ? 'none' : result.result;
          MessageBox.show(this.dialog, `User response : ${dialogResult}`);
    });
  }

  openConfirmModal() {
    console.log('openConfirmModal()...');

    this.title = 'タイトル表示部';
    this.iconType = IconType.None;
    this.message = 'このメッセージが見えますか？';
    this.buttonType = ButtonType.AcceptReject;
    this.width = '60%';

    MessageBox.show(this.dialog, this.message, this.title,
          this.buttonType, this.iconType, this.width)
        .subscribe( result => {
          const dialogResult = (result === undefined) ? 'none' : result.result;
          MessageBox.show(this.dialog, `User response : ${dialogResult}`);
    });
  }
}
