import { MatDialog } from "@angular/material";
import { AlertComponent } from "../../modal/alert/alert.component";
import { IconType, ButtonType } from '../../modal/model/modal-data';

export class MessageBox {
  static show(dialog: MatDialog, 
              message: string, 
              title = 'Information', 
              buttonType = ButtonType.Ok,
              iconType: IconType = IconType.None, 
              width = '55%',
              allow_outside_click = false) {
    const dialogRef = dialog.open( AlertComponent, {
      data: {
        message: message || '',
        title: title || 'Information',
        buttonType: buttonType || ButtonType.Ok,
        iconType: iconType || IconType.None
      },
      width: width
    });    
    return dialogRef.afterClosed();     
  }
}

