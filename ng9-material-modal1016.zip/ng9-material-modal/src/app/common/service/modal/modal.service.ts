import { Injectable } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { ButtonType, AlertType } from '../../modal/model/modal-data';


@Injectable({
  providedIn: 'root'
})
export class ModalService {

  constructor(private dialog: MatDialog) { }

  async openAlertDialog(
                          title: string, 
                          content: string, 
                          buttonType: ButtonType, 
                          width:  string, 
                          alertType: AlertType) {

    const {AlertComponent} = await import('../../modal/alert/alert.component');
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = width;
    dialogConfig.data ={
      title: title,
      content: content,
      buttonType: buttonType,
      alertType: alertType
    }
    const dialogRef = this.dialog.open(AlertComponent, dialogConfig);
  }
}
