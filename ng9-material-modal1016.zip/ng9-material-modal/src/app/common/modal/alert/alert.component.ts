import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ModalData, IconType } from '../model/modal-data';


@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit {
  title: string;
  iconType: IconType;
  message: string;
  information: string;
  buttonType: number;
  constructor(public dialogRef: MatDialogRef<AlertComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ModalData) {

    this.title = data.title;
    this.iconType = data.iconType;
    this.message = data.message;
    this.buttonType = data.buttonType;
    this.dialogRef.disableClose = true;    
  }

  ngOnInit() {
    console.log(this.data);
  }
  
  onClose() {
    this.dialogRef.close();
  }

  getAlertIcon() {
    switch (this.data.iconType) {
      case IconType.None:
        return 'none';
      case IconType.Info:
        //TODO: info Icon取得
        return 'info';
      case IconType.Warning:
        //TODO: warning Icon取得
        return 'warning';
      case IconType.Error:
        //TODO: error Icon取得
        return 'error';
    }
  }

  //TODO: tabindex="0"でFocus設定
  setFocusButton() {

  }

  onOk() {
    this.dialogRef.close({result: "ok"});
  }
  onCancel() {
    this.dialogRef.close({result: "cancel"});
  }
  onYes() {
    this.dialogRef.close({result: "yes"});
  }
  onNo() {
    this.dialogRef.close({result: "no"});
  }
  onAccept() {
    this.dialogRef.close({result: "accept"});
  }
  onReject() {
    this.dialogRef.close({result: "reject"});
  }

}
