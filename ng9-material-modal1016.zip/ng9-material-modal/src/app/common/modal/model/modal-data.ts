export class ModalData {
    title: string;
    iconType: IconType;
    message: string;
    buttonType: ButtonType;
    width: string;

    constructor(data?) {
      if (data) {
        this.title = data.title;
        this.message = data.message;
        this.iconType = data.iconType;
        this.buttonType = data.buttonType;
        this.width = data.width;
      }
    }
  }
  
export enum IconType {
  None,
  Info,
  Warning,
  Error
}
  
export  enum ButtonType {
  Ok,
  OkCancel,
  YesNo,
  AcceptReject
}
