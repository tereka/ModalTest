import { Component, OnInit } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { NormalLoadComponent } from '../modal/normal-load/normal-load.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  normalLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '50%';
    this.dialog.open(NormalLoadComponent, dialogConfig);
  }

  async lazyLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '50%';

    // dialog.openする直前に非同期でモジュールインポート
    const {LazyLoadComponent} = await import('../modal/lazy-load/lazy-load.component');
    this.dialog.open(LazyLoadComponent, dialogConfig);
  }

}
