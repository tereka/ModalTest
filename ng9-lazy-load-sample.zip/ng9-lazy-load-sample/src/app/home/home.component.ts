import { Component, OnInit } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { NormalLoadComponent } from '../component/modal/normal-load/normal-load.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  normalLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';
    this.dialog.open(NormalLoadComponent, dialogConfig);
  }

  async lazyLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';

    // dialog.openする直前に非同期でモジュールインポート
    const {LazyLoadComponent} = await import('../component/modal/lazy-load/lazy-load.component');
    this.dialog.open(LazyLoadComponent, dialogConfig);
  }

  openMessageBox(id: number) {

  }
}
