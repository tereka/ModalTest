import { MatDialog } from '@angular/material';
import { ButtonType, IconType, ModalData } from './model/message-box-data';


export class MessageBox {
  static async show(dialog: MatDialog,
                    message: string,
                    title = '',
                    buttonType = ButtonType.Ok,
                    iconType: IconType = IconType.None,
                    width = '55%') {

     const {MessageBoxComponent} = await import('./message-box.component');
     const dialogRef = dialog.open( MessageBoxComponent, {
      data: {
        message: message || '',
        title: title || 'Information',
        buttonType: buttonType || ButtonType.Ok,
        iconType: iconType || IconType.None
      },
      width
    });
     return dialogRef.afterClosed();
  }

  static async Show(dialog: MatDialog, data: ModalData) {

    const {MessageBoxComponent} = await import('./message-box.component');
    const dialogRef = dialog.open( MessageBoxComponent, {
        data: {
        message: data.message || '',
        title: data.title || 'Information',
        buttonType: data.buttonType || ButtonType.Ok,
        iconType: data.iconType || IconType.Info
        },
        width: data.width
    });
    return dialogRef.afterClosed();
  }
}

