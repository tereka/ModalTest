import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ModalData, IconType } from './model/message-box-data';

@Component({
  selector: 'app-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.scss']
})
export class MessageBoxComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<MessageBoxComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ModalData) {
  }

  ngOnInit() {
    console.log(this.data);
  }

  onClose() {
    this.dialogRef.close();
  }

  getStatusIcon() {
    switch (this.data.iconType) {
      case IconType.None:
        return 'none';
      case IconType.Info:
        // TODO: info Icon取得
        return 'info';
      case IconType.Warning:
        // TODO: warning Icon取得
        return 'warning';
      case IconType.Error:
        // TODO: error Icon取得
        return 'error';
    }
  }

  onOk() {
    this.dialogRef.close({result: 'ok'});
  }
  onCancel() {
    this.dialogRef.close({result: 'cancel'});
  }
  onYes() {
    this.dialogRef.close({result: 'yes'});
  }
  onNo() {
    this.dialogRef.close({result: 'no'});
  }
  onAccept() {
    this.dialogRef.close({result: 'accept'});
  }
  onReject() {
    this.dialogRef.close({result: 'reject'});
  }

}
