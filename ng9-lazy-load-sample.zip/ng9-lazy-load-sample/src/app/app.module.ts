import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NormalLoadComponent } from './component/modal/normal-load/normal-load.component';
import { MaterialModule } from './material/material.module';
import { HomeComponent } from './home/home.component';

// Lazy LoadするcomponetをAppModuleに登録しない
// import { LazyLoadComponent } from './component/modal/lazy-load/lazy-load.component';

@NgModule({
  declarations: [
    AppComponent,
    NormalLoadComponent,
    HomeComponent,

    // LazyLoadComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    MatNativeDateModule,
  ],
  entryComponents: [NormalLoadComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
