import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessageBoxComponent } from './message-box.component';
import { MaterialModule } from 'src/app/material/material.module';

@NgModule({
  declarations: [MessageBoxComponent],
  imports: [
    CommonModule,
    MaterialModule
  ]
})
export class MessageBoxModule { }
