import { MatDialog } from '@angular/material';
import { ButtonType, IconType, MessageBoxData, FocusButton } from './model/message-box-data';


export class MessageBox {

  static async show(dialog: MatDialog,
                    title = '',
                    message = '',
                    buttonType = ButtonType.Ok,
                    iconType = IconType.None,
                    focusButton = FocusButton.None,
                    width = '55%') {

     const {MessageBoxComponent} = await import('./message-box.component');
     const dialogRef = dialog.open( MessageBoxComponent, {
      data: {
        title: title || 'Information',
        message: message || '',
        buttonType: buttonType || ButtonType.Ok,
        iconType: iconType || IconType.None,
        focusButton: focusButton || FocusButton.None,
      },
      width
    });
     return dialogRef.afterClosed();
  }

  static async Show(dialog: MatDialog, data: MessageBoxData) {
    const {MessageBoxComponent} = await import('./message-box.component');
    const dialogRef = dialog.open( MessageBoxComponent, {
        data: {
          title: data.title || 'Information',
          message: data.message || '',
          buttonType: data.buttonType || ButtonType.Ok,
          iconType: data.iconType || IconType.Info,
          focusButton: FocusButton.None,
        },
        width: data.width
    });
    return dialogRef.afterClosed();
  }
}

