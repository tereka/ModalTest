import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-stepper',
  templateUrl: './simple-stepper.component.html',
  styleUrls: ['./simple-stepper.component.scss']
})
export class SimpleStepperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  reset() {
    console.log('リセット');
  }

}
