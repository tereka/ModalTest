import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StepperExampleComponent } from './stepper-example.component';
import { MaterialModule } from 'src/app/material/material.module';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@NgModule({
  declarations: [StepperExampleComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormGroup,
    FormBuilder,



  ],
  entryComponents: [StepperExampleComponent],

})
export class StepperExampleModule { }
