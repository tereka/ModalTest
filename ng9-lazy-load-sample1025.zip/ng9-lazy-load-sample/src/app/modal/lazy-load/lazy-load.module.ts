import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'src/app/material/material.module';
import { LazyLoadComponent } from './lazy-load.component';

@NgModule({
  declarations: [LazyLoadComponent],
  imports: [
    CommonModule,
    MaterialModule,
  ],
  entryComponents: [LazyLoadComponent],
})
export class LazyLoadModule { }
