import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';

import { ModalTemplateComponent } from './common/modal/modal-template.component';
import { ModalTestComponent } from './modal-test.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    ModalTestComponent,
    ModalTemplateComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule
  ],
  providers: [],
  entryComponents: [ModalTemplateComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
