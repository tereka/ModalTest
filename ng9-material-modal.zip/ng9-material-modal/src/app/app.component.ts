import { Component } from '@angular/core';
import { ModalService } from './common/service/modal/modal.service';
import { ButtonType, AlertType } from './common/modal/model/modal-data';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ng9-material-modal';

  constructor(private modalService: ModalService) {}

  openInfoModal() {
    console.log('openInfoModal()...');
    var result = this.modalService.openAlertDialog(
      'Infomation', 'ここにInfomationメッセージを書きます!!', 
      ButtonType.OK, '60%', AlertType.INFO);
  }

  openWarningModal() {
    console.log('openWarningModal()...');
    var result = this.modalService.openAlertDialog('Warning', 
                'ここにWarningメッセージを書きます!!', ButtonType.OK, '300px', AlertType.WARNING);
  }

  openErrorModal() {
    console.log('openErrorModal()...');
    var result = this.modalService.openAlertDialog('Error', 
                'ここにErrorメッセージを書きます!!', ButtonType.OK, '50%', AlertType.ERROR);
  }

  openConfirmModal() {
    console.log('openConfirmModal()...');
    var result = this.modalService.openAlertDialog('Confirm', 
                'ここにConfirmメッセージを書きます!!', ButtonType.OK, '40%', AlertType.CONFIRM);
  }
}
