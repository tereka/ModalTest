export class ModalData {
    title: string;
    content: string;
    alertType: AlertType;
    buttonType: ButtonType;
    buttonLabel: string[];
    width: string;

    constructor(data?) {
      if (data) {
        this.title = data.title;
        this.content = data.content;
        this.alertType = data.alertType;
        this.buttonType = data.buttonType;
        this.buttonLabel = data.buttonLabel;
        this.width = data.width;
      }
    }
  }
  
  export enum AlertType {
    INFO,
    WARNING,
    ERROR,
    CONFIRM
  }

  export enum ButtonType {
    YESNO,
    OK
  }
  