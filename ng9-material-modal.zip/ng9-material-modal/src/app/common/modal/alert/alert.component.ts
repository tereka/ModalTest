import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ModalService } from '../../service/modal/modal.service';
import { ModalData, AlertType } from '../model/modal-data';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit {

  constructor(private service: ModalService,
    private dialogRef: MatDialogRef<AlertComponent>,
    @Inject(MAT_DIALOG_DATA) 
    public data: ModalData) {
    }

  ngOnInit() {
    console.log(this.data.title);
    console.log(this.data.content);
    console.log(this.data.buttonType.toString());
    console.log(this.data.alertType.toString());
    console.log(this.data.width);
  }
  
  onClose() {
    this.dialogRef.close();
  }

  getAlertIcon() {
    switch (this.data.alertType) {
      case AlertType.INFO:
        return 'info';
      case AlertType.WARNING:
        return 'warning';
      case AlertType.ERROR:
        return 'error';
      case AlertType.CONFIRM:
        return 'confirm';
    }
  }

}
