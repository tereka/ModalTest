import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertComponent } from './alert.component';
import { MaterialModule } from 'src/app/material/material.module';


@NgModule({
  declarations: [AlertComponent],
  imports: [
    CommonModule,
    MaterialModule
  ]
})
export class AlertModule { }
