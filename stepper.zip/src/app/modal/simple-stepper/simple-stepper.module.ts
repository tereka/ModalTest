import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimpleStepperComponent } from './simple-stepper.component';
import { MaterialModule } from 'src/app/material/material.module';



@NgModule({
  declarations: [SimpleStepperComponent],
  imports: [
    CommonModule,
    MaterialModule,
  ],
  entryComponents: [SimpleStepperComponent],

})
export class SimpleStepperModule { }
