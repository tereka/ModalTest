import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS, StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepper } from '@angular/material/stepper';



export interface DialogData {
  title: string;
  content: string;
}


@Component({
  selector: 'app-simple-stepper',
  templateUrl: './simple-stepper.component.html',
  styleUrls: ['./simple-stepper.component.scss'],
  providers: [{
    // エラー表示用
    provide: STEPPER_GLOBAL_OPTIONS, useValue: {showError: true}
  }]
})
export class SimpleStepperComponent implements OnInit {

  stepper: MatStepper;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  index = 0;
  checked = false;
  indeterminate = false;
  labelPosition = 'after';
  disabled = false;
  completed = false;
  
  constructor(private fb: FormBuilder,
              public dialogRef: MatDialogRef<SimpleStepperComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData) {

                this.firstFormGroup = this.fb.group({
                  firstCtrl: ['', Validators.required]
                });
                this.secondFormGroup = this.fb.group({
                  secondCtrl: ['', Validators.required]
                });

                this.thirdFormGroup = this.fb.group({
                  hideRequired: false,
                  floatLabel: 'auto',
                });
  }

  ngOnInit() {
  }

  onApply() {
    console.log('適用');
  }

  onClose() {
    this.dialogRef.close();
  }

  doSomething(event: StepperSelectionEvent) {
    this.stepper.selectedIndex = this.index;
  }

  checkValidation(nIndex: number): boolean {
    this.index = nIndex++;
    return true;
  }

  completeStep(): void {
    this.completed = true;
  }
}
