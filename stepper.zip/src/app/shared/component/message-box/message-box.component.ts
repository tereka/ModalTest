import { Subject } from 'rxjs';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MessageBoxData, IconType } from './model/message-box-data';


// ********************************************************
// ※ Local環境で実行するときの注意点
// Localの環境で使うときBuildまたはコンパイル時（npm start時）、
// エラーが出る場合があります
// MessageBoxModuleクラスをなぜか参照しないようです。
// その場合は、以下の@NgModuleのコメントを外して使ってみてください。
//
// ※ CT環境にBuildするとき(npm run build:ct)は、
// MessageBoxModuleクラスを正常に参照しますので
// @NgModuleはコメントアウトして使ってください。
// *********************************************************
// -------------------------------------------------------->
// @NgModule({
//   declarations: [MessageBoxComponent],
//   imports: [CommonModule, SharedModule, MaterialModule],
//   exports: [MessageBoxComponent],
// })
// <--------------------------------------------------------

@Component({
  selector: 'app-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.scss'],
})
export class MessageBoxComponent implements OnInit {
  destroy$ = new Subject<any>();
  label: any;

  constructor(
    public dialogRef: MatDialogRef<MessageBoxComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: MessageBoxData
  ) {
    // dialogの外をクリックしてもクローズしない
    this.dialogRef.disableClose = true;
  }

  ngOnInit() {
    // tslint:disable-next-line: no-console
    console.info(this.data);
  }

  onClose() {
    this.dialogRef.close();
  }

  getStatusIcon() {
    switch (this.data.iconType) {
      case IconType.None:
        return 'None';

      case IconType.Error:
        return 'fj-icon fj-icon-status-error';

      case IconType.Important:
        return 'fj-icon fj-icon-status-important';

      case IconType.Info:
        return 'fj-icon fj-icon-status-info';

      case IconType.Normal:
        return 'fj-icon fj-icon-status-normal';

      case IconType.Pause:
        return 'fj-icon fj-icon-status-pause';

      case IconType.Running:
        return 'fj-icon fj-icon-status-running';

      case IconType.Stop:
        return 'fj-icon fj-icon-status-stop';

      case IconType.Unkown:
        return 'fj-icon fj-icon-status-unknown';

      case IconType.Warning:
        return 'fj-icon fj-icon-status-warning';
    }
  }

  onOk() {
    this.dialogRef.close({ result: 'ok' });
  }

  onCancel() {
    this.dialogRef.close({ result: 'cancel' });
  }

  onYes() {
    this.dialogRef.close({ result: 'yes' });
  }

  onNo() {
    this.dialogRef.close({ result: 'no' });
  }

  onApply() {
    this.dialogRef.close({ result: 'apply' });
  }

  onConfirm() {
    this.dialogRef.close({ result: 'confirm' });
  }
}
