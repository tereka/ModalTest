import { MatDialog } from '@angular/material/dialog';
import {
  ButtonType,
  FocusButton,
  IconType,
  MessageBoxData,
} from './model/message-box-data';

/**
 * 共通モーダル：単純メッセージ表示モーダル
 */
export class MessageBox {
  /**
   * MessageBoxを表示する
   * @param dialog MatDialog
   * @param title title
   * @param message message
   * @param buttonType ButtonType
   * @param iconType IconType
   * @param focusButton FocusButton
   * @param width width
   */
  static async show(
    dialog: MatDialog,
    title: string,
    message: string,
    buttonType = ButtonType.Ok,
    iconType = IconType.None,
    focusButton = FocusButton.None,
    width = '50%'
  ) {
    const { MessageBoxComponent } = await import('./message-box.component');
    const dialogRef = dialog.open(MessageBoxComponent, {
      data: {
        title: title || '',
        message: message || '',
        buttonType: buttonType || ButtonType.Ok,
        iconType: iconType || IconType.None,
        focusButton: focusButton || FocusButton.None,
      },
      width,
    });

    return dialogRef.afterClosed();
  }

  /**
   * MessageBoxを表示する
   * @param dialog MatDialog
   * @param dialogData MessageBoxData
   */
  static async Show(dialog: MatDialog, data: MessageBoxData) {
    const { MessageBoxComponent } = await import('./message-box.component');
    const dialogRef = dialog.open(MessageBoxComponent, {
      data: {
        title: data.title || '',
        message: data.message || '',
        buttonType: data.buttonType || ButtonType.Ok,
        iconType: data.iconType || IconType.None,
        focusButton: data.focusButton || FocusButton.None,
      },
      width: data.width,
    });

    return dialogRef.afterClosed();
  }
}
