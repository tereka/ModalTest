/**
 * 共通モーダルOptionデータ
 */
export class MessageBoxData {
  title: string;
  message: string;
  buttonType: ButtonType;
  iconType: IconType;
  focusButton: FocusButton;
  width: string;

  constructor(data?) {
    if (data) {
      this.title = data.title;
      this.message = data.message;
      this.buttonType = data.buttonType;
      this.iconType = data.iconType;
      this.focusButton = data.focusButton;
      this.width = data.width;
    }
  }
}

/**
 * Icon Type
 */
export enum IconType {
  None = 0,
  Error,
  Important,
  Info,
  Normal,
  Pause,
  Running,
  Stop,
  Unkown,
  Warning,
}

/**
 * Button Type
 */
export enum ButtonType {
  Ok = 0,
  OkCancel,
  YesNo,
  ApplyCancel,
}

/**
 * Focus Button
 */
export enum FocusButton {
  None = 0,
  Left,
  Right,
  One,
}
