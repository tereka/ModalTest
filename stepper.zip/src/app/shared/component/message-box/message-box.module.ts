import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessageBoxComponent } from './message-box.component';
import { MaterialModule } from 'src/app/material/material.module';
import { SharedModule } from '../../shared.module';
import { MessageBox } from './message-box';

@NgModule({
  declarations: [MessageBoxComponent],
  imports: [CommonModule, SharedModule, MaterialModule],
  exports: [MessageBoxComponent],
  entryComponents: [MessageBoxComponent],
  providers: [MessageBox],
})
export class MessageBoxModule {}
