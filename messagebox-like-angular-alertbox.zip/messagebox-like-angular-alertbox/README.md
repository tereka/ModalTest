
# MessageBox : Just Another Custom Alert Implementation for Angular

![](doc/messagebox.gif)

This is discussed in my [personal blog](https://trashvin.blogspot.com/2017/12/just-another-custom-alert-for-angular.html) as well as on my [Medium post](https://medium.com/@m3lles/just-another-custom-alert-for-angular-c288bebc3c96).

