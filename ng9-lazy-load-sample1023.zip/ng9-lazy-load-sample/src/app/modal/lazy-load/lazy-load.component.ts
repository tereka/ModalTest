import {Component} from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { IconType, ButtonType, MessageBoxData, FocusButton } from 'src/app/shared/component/message-box/model/message-box-data';
import { MessageBox } from 'src/app/shared/component/message-box/message-box';


export interface PeriodicElementLazy {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElementLazy[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  // {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  // {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  // {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];


@Component({
  selector: 'app-lazy-load',
  templateUrl: './lazy-load.component.html',
  styleUrls: ['./lazy-load.component.scss']
})
export class LazyLoadComponent {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;


  constructor(private dialog: MatDialog,
              public dialogRef: MatDialogRef<LazyLoadComponent>) { }

  async openMessageBox() {
    const data = {
      title: 'タイトル表示部',
      message: 'このメッセージが見えますか？',
      buttonType: ButtonType.YesNo,
      iconType: IconType.None,
      focusButton: FocusButton.None,
      width: '50%'
    };

    (await (MessageBox.Show(this.dialog, data)))
      .subscribe( result => {
      const dialogResult = (result === undefined) ? 'none' : result.result;

      // モーダルを閉じた後の処理があれば、dialogResultを判定して行います。
      if (dialogResult === 'yes') {
        MessageBox.show(this.dialog, '', `ユーザの選択 : ${dialogResult}`);
      } else {
        console.log('dialogResult : ', dialogResult);
      }
    });
  }

  onClose() {
    this.dialogRef.close();
  }
}
