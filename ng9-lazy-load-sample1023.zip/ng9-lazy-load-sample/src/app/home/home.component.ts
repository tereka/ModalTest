import { Component, OnInit } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { NormalLoadComponent } from '../modal/normal-load/normal-load.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  // ConstructorにMatDialog型のクラス変数追加
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  // 一般的なモーダルを開く
  normalLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '50%';
    // Open Modal
    this.dialog.open(NormalLoadComponent, dialogConfig);
  }

  // Lazy Loadでモーダルを開く
  async lazyLoading() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '50%';

    // dialog.openする直前に非同期でモジュールインポート
    const {LazyLoadComponent} = await import('../modal/lazy-load/lazy-load.component');
    // Open Modal
    this.dialog.open(LazyLoadComponent, dialogConfig);
  }
}
