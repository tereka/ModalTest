import { Observable, Subject } from 'rxjs';
import { Component, OnInit, Inject, NgModule } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MessageBoxData, IconType } from './model/message-box-data';
import { takeUntil } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'src/app/material/material.module';

// @NgModule({
//   declarations: [MessageBoxComponent],
//   imports: [CommonModule, MaterialModule],
//   // exports: [MessageBoxComponent],
//   // entryComponents: [MessageBoxComponent],
// })
@Component({
  selector: 'app-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.scss'],
})
export class MessageBoxComponent implements OnInit {
  destroy$ = new Subject<any>();
  label: any;

  constructor(
    public dialogRef: MatDialogRef<MessageBoxComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: MessageBoxData
  ) {
    this.dialogRef.disableClose = true;
  }

  ngOnInit() {}

  onClose() {
    this.dialogRef.close();
  }

  getStatusIcon() {
    console.log('data.iconType', this.data.iconType);

    switch (this.data.iconType) {
      case IconType.None:
        return 'None';

      case IconType.Error:
        return 'error';

      case IconType.Important:
        return 'important';

      case IconType.Info:
        return 'info';

      case IconType.Normal:
        return 'normal';

      case IconType.Pause:
        return 'pause';

      case IconType.Running:
        return 'running';

      case IconType.Stop:
        return 'stop';

      case IconType.Unkown:
        return 'unknown';

      case IconType.Warning:
        return 'warning';
    }
  }

  onOk() {
    this.dialogRef.close({ result: 'ok' });
  }

  onCancel() {
    this.dialogRef.close({ result: 'cancel' });
  }

  onYes() {
    this.dialogRef.close({ result: 'yes' });
  }

  onNo() {
    this.dialogRef.close({ result: 'no' });
  }

  onApply() {
    this.dialogRef.close({ result: 'apply' });
  }

  onConfirm() {
    this.dialogRef.close({ result: 'confirm' });
  }
}
